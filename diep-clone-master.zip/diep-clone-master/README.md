# diep.io-clone
![GitHub License](https://img.shields.io/github/license/Diep-clone/diep-clone_golang?style=flat-square)
![GitHub commit activity](https://img.shields.io/github/commit-activity/m/diep-clone/diep-clone_golang?style=flat-square)
[![HitCount](http://hits.dwyl.com/Diep-clone/diep-clone_golang.svg)](http://hits.dwyl.com/Diep-clone/diep-clone_golang)

This repo is Diep.io's Clone Version.

The goal of this project is to copy the web game diep.io as same as possible.
Currently, this project is stopped practically due to the vacancy of lead programmer.

## 📚 Project Stack
### Front end (JS)
- Webpack
- babel

### Back end (Golang)
- gorilla/websocket
- sirupsen/logrus

Before introducing this project,
these are the nicknames of the "researchers" who gave their attention to this project and have researched various needed information about diep.io.
Without them, this project would not have progressed.
I would like to express my gratitude to the following researchers:

 - [K] YouTube
 - 피로⚛Firo_SF
 - 항해사 (Voyager)
 - 케빈 (Kevin)

Plus, I would like to thank 
 - 레인우드 (Rainwood)

who made the foundation for this project.

Undeveloped parts are arranged in the Projects column.

---
Copyright © 2019-2020
